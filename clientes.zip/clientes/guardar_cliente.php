<?php
include("db.php");

// Recoger datos
$cedula = $_POST["cedula"];
$nombre = $_POST["nombre"];
$telefono = $_POST["telefono"];
$email = $_POST["email"];
$direccion = $_POST["direccion"];
$comentarios = $_POST["comentarios"];

// Validar si la cédula ya existe
$sql_check = "SELECT cedula FROM clientes WHERE cedula = ?";
$stmt = $conn->prepare($sql_check);
$stmt->bind_param("s", $cedula);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo "<script>alert('❌ La cédula ya está registrada.'); window.history.back();</script>";
    exit;
}

$stmt->close();

// Insertar nuevo cliente
$sql = "INSERT INTO clientes (cedula, nombre, telefono, email, direccion, comentarios) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssss", $cedula, $nombre, $telefono, $email, $direccion, $comentarios);

if ($stmt->execute()) {
    echo "<script>alert('✅ Cliente registrado correctamente'); window.location.href='index.html';</script>";
} else {
    echo "<script>alert('Error al guardar: " . $stmt->error . "'); window.history.back();</script>";
}

$stmt->close();
$conn->close();
?>

