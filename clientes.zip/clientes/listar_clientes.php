<?php
include 'db.php';
$res = $conn->query("SELECT * FROM clientes ORDER BY nombre ASC");
$clientes = [];
while($row = $res->fetch_assoc()) {
    $clientes[] = $row;
}
echo json_encode($clientes);
?>
