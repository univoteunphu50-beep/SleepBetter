let productosDisponibles = [];
let paginaActual = 1;
let facturasPorPagina = 5;
let facturasCargadas = [];

window.addEventListener('DOMContentLoaded', () => {
  cargarClientes();
  cargarProductos();
  agregarFila();
  document.getElementById("cliente").addEventListener("change", completarCliente);
  mostrarTab('tab-facturar');
});

// Tabs
function mostrarTab(id) {
  document.getElementById("tab-facturar").classList.add("hidden");
  document.getElementById("tab-consultar").classList.add("hidden");

  document.getElementById(id).classList.remove("hidden");

  const navLinks = document.querySelectorAll(".nav-link");
  navLinks.forEach(link => link.classList.remove("active"));
  if (id === "tab-facturar") {
    navLinks[0].classList.add("active");
  } else {
    navLinks[1].classList.add("active");
  }

  if (id === "tab-consultar") {
    buscarFacturas();
  }
}

function cargarClientes() {
  fetch("../clientes/listar_clientes.php")
    .then(res => res.json())
    .then(clientes => {
      const select = document.getElementById("cliente");
      select.innerHTML = '<option value="">-- Seleccione un cliente --</option>';
      clientes.forEach(c => {
        const option = document.createElement("option");
        option.value = c.cedula;
        option.textContent = c.nombre;
        option.dataset.telefono = c.telefono;
        option.dataset.email = c.email;
        option.dataset.direccion = c.direccion;
        select.appendChild(option);
      });
    });
}

function completarCliente() {
  const sel = document.getElementById("cliente");
  const opt = sel.options[sel.selectedIndex];
  if (!opt) return;
  document.getElementById("cliente-cedula").value = opt.value || '';
  document.getElementById("cliente-telefono").value = opt.dataset.telefono || '';
  document.getElementById("cliente-email").value = opt.dataset.email || '';
  document.getElementById("cliente-direccion").value = opt.dataset.direccion || '';
}

function cargarProductos() {
  fetch("../productos/listar_productos.php")
    .then(res => res.json())
    .then(data => {
      productosDisponibles = data;
      agregarDatalist();
    });
}

function agregarDatalist() {
  let ids = document.createElement("datalist");
  ids.id = "ids";
  productosDisponibles.forEach(p => {
    let opt = document.createElement("option");
    opt.value = p.id;
    ids.appendChild(opt);
  });
  document.body.appendChild(ids);

  let nombres = document.createElement("datalist");
  nombres.id = "nombres";
  productosDisponibles.forEach(p => {
    let opt = document.createElement("option");
    opt.value = p.nombre;
    nombres.appendChild(opt);
  });
  document.body.appendChild(nombres);
}

function agregarFila() {
  const tbody = document.getElementById("detalle-productos");
  const tr = document.createElement("tr");

  tr.innerHTML = `
    <td><input list="ids" class="form-control id-input" oninput="sincronizar(this, 'id')"></td>
    <td><input list="nombres" class="form-control nombre-input" oninput="sincronizar(this, 'nombre')"></td>
    <td><input type="number" class="form-control precio" readonly></td>
    <td class="text-center"><input type="checkbox" class="form-check-input aplicar-itbis"></td>
    <td><input type="number" class="form-control cantidad" value="1" min="1"></td>
    <td><input type="number" class="form-control precio-itbis" readonly></td>
    <td><input type="number" class="form-control descuento" value="0" min="0" max="100"></td>
    <td><input type="number" class="form-control total" readonly></td>
    <td><button class="btn btn-sm btn-danger" onclick="this.closest('tr').remove(); calcularTotales();">🗑</button></td>
  `;

  tbody.appendChild(tr);
  asignarEventos(tr);
}

function sincronizar(input, tipo) {
  const fila = input.closest("tr");
  let producto;

  if (tipo === 'id') {
    producto = productosDisponibles.find(p => p.id === input.value);
  } else {
    producto = productosDisponibles.find(p => p.nombre.toLowerCase() === input.value.toLowerCase());
  }

  if (producto) {
    fila.querySelector(".id-input").value = producto.id;
    fila.querySelector(".nombre-input").value = producto.nombre;
    fila.querySelector(".precio").value = parseFloat(producto.precio).toFixed(2);
    actualizarFila(fila);
  }
}

function asignarEventos(fila) {
  fila.querySelectorAll("input").forEach(inp => {
    inp.addEventListener("input", () => actualizarFila(fila));
  });
}

function actualizarFila(fila) {
  const precio = parseFloat(fila.querySelector(".precio").value) || 0;
  const aplicarITBIS = fila.querySelector(".aplicar-itbis").checked;
  const cantidad = parseFloat(fila.querySelector(".cantidad").value) || 1;
  const descuento = parseFloat(fila.querySelector(".descuento").value) || 0;

  const precioFinal = precio * (aplicarITBIS ? 1.18 : 1);
  const total = precioFinal * cantidad * (1 - descuento / 100);

  fila.querySelector(".precio-itbis").value = precioFinal.toFixed(2);
  fila.querySelector(".total").value = total.toFixed(2);

  calcularTotales();
}

function calcularTotales() {
  let subtotal = 0;
  let itbis = 0;

  document.querySelectorAll("#detalle-productos tr").forEach(fila => {
    const precio = parseFloat(fila.querySelector(".precio").value) || 0;
    const cantidad = parseFloat(fila.querySelector(".cantidad").value) || 0;
    const descuento = parseFloat(fila.querySelector(".descuento").value) || 0;
    const aplicar = fila.querySelector(".aplicar-itbis").checked;

    const base = precio * cantidad * (1 - descuento / 100);
    subtotal += base;
    if (aplicar) {
      itbis += base * 0.18;
    }
  });

  document.getElementById("subtotal").innerText = subtotal.toFixed(2);
  document.getElementById("itbis").innerText = itbis.toFixed(2);
  document.getElementById("total").innerText = (subtotal + itbis).toFixed(2);
}

// Guardar factura
document.getElementById("form-factura").addEventListener("submit", function (e) {
  e.preventDefault();

  const productos = [];
  const filas = document.querySelectorAll("#detalle-productos tr");

  filas.forEach(fila => {
    const id = fila.querySelector(".id-input").value;
    const nombre = fila.querySelector(".nombre-input").value;
    const precio = parseFloat(fila.querySelector(".precio").value) || 0;
    const aplicar = fila.querySelector(".aplicar-itbis").checked;
    const cantidad = parseInt(fila.querySelector(".cantidad").value) || 1;
    const precioFinal = parseFloat(fila.querySelector(".precio-itbis").value) || 0;
    const descuento = parseFloat(fila.querySelector(".descuento").value) || 0;
    const total = parseFloat(fila.querySelector(".total").value) || 0;

    if (id && nombre) {
      productos.push({ id, nombre, precio, itebis: aplicar, cantidad, precioFinal, descuento, total });
    }
  });

  if (productos.length === 0) {
    Swal.fire("Error", "Debe agregar al menos un producto.", "error");
    return;
  }

  const formData = new FormData(this);
  formData.append("productos", JSON.stringify(productos));

  fetch("facturar.php", {
    method: "POST",
    body: formData
  })
    .then(res => res.text())
    .then(res => {
      Swal.fire("Éxito", "Factura registrada correctamente.", "success");
      this.reset();
      document.getElementById("detalle-productos").innerHTML = "";
      agregarFila();
      calcularTotales();
    })
    .catch(() => {
      Swal.fire("Error", "Ocurrió un error al guardar la factura.", "error");
    });
});

/// CONSULTA FACTURAS

function buscarFacturas() {
  const cliente = document.getElementById("filtro-cliente").value;
  const producto = document.getElementById("filtro-producto").value;
  const fecha = document.getElementById("filtro-fecha").value;

  const params = new URLSearchParams();
  if (cliente) params.append("cliente", cliente);
  if (producto) params.append("producto", producto);
  if (fecha) params.append("fecha", fecha);

  fetch("consultar_facturas.php?" + params.toString())
    .then(res => res.json())
    .then(data => {
      facturasCargadas = data;
      paginaActual = 1;
      renderizarFacturas();
    });
}

function renderizarFacturas() {
  const tbody = document.getElementById("tabla-consulta-body");
  tbody.innerHTML = "";

  const inicio = (paginaActual - 1) * facturasPorPagina;
  const fin = inicio + facturasPorPagina;
  const facturasPagina = facturasCargadas.slice(inicio, fin);

  facturasPagina.forEach(f => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${f.id}</td>
      <td>${f.fecha}</td>
      <td>${f.cliente}</td>
      <td>${f.productos}</td>
      <td>$${f.total}</td>
      <td><button class="btn btn-outline-success btn-sm" onclick="window.print()">🖨 Imprimir</button></td>
    `;
    tbody.appendChild(tr);
  });
}

function paginaAnterior() {
  if (paginaActual > 1) {
    paginaActual--;
    renderizarFacturas();
  }
}

function paginaSiguiente() {
  if ((paginaActual * facturasPorPagina) < facturasCargadas.length) {
    paginaActual++;
    renderizarFacturas();
  }
}
