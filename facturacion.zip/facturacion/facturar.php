<?php
include("../conexion.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fecha = date("Y-m-d");
    $vendedor = $_POST["vendedor"] ?? "Desconocido";
    $cedula_cliente = $_POST["cliente"] ?? "";

    $productos = json_decode($_POST["productos"], true);

    if (empty($productos)) {
        http_response_code(400);
        echo "No se proporcionaron productos.";
        exit;
    }

    // Calcular subtotal, itbis y total
    $subtotal = 0;
    $itbis = 0;
    $total = 0;

    foreach ($productos as $p) {
        $precio = floatval($p["precio"]);
        $cantidad = intval($p["cantidad"]);
        $descuento = floatval($p["descuento"]);
        $aplicarITBIS = $p["itebis"] ? true : false;

        $base = $precio * $cantidad * (1 - $descuento / 100);
        $subtotal += $base;

        if ($aplicarITBIS) {
            $itbis += $base * 0.18;
        }

        $total += floatval($p["total"]);
    }

    // Insertar en facturas
    $stmt = $conn->prepare("INSERT INTO facturas (fecha, vendedor, cedula_cliente, subtotal, itbis, total) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $fecha, $vendedor, $cedula_cliente, $subtotal, $itbis, $total);
    $stmt->execute();
    $id_factura = $stmt->insert_id;
    $stmt->close();

    // Insertar productos
    $stmt_detalle = $conn->prepare("INSERT INTO detalle_factura (id_factura, id_producto, nombre, precio_unitario, cantidad, total) VALUES (?, ?, ?, ?, ?, ?)");
    foreach ($productos as $p) {
        $id_producto = intval($p["id"]);
        $nombre = $p["nombre"];
        $precio = floatval($p["precio"]);
        $cantidad = intval($p["cantidad"]);
        $total_linea = floatval($p["total"]);

        $stmt_detalle->bind_param("iisddi", $id_factura, $id_producto, $nombre, $precio, $cantidad, $total_linea);
        $stmt_detalle->execute();
    }
    $stmt_detalle->close();

    echo "Factura guardada correctamente.";
}
?>

