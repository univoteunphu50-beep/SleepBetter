<?php
// Archivo: consultar_facturas.php

header('Content-Type: application/json');
include("../conexion.php"); // Asegúrate que la ruta sea correcta

$cliente = $_GET['cliente'] ?? '';
$producto = $_GET['producto'] ?? '';
$fecha = $_GET['fecha'] ?? '';

$sql = "
    SELECT 
        f.id,
        f.fecha,
        f.cedula_cliente AS cliente,
        GROUP_CONCAT(d.nombre SEPARATOR ', ') AS productos,
        SUM(d.total) AS total
    FROM facturas f
    INNER JOIN detalle_factura d ON f.id = d.id_factura
    WHERE 1=1
";

// Filtros dinámicos
if (!empty($cliente)) {
    $cliente = $conn->real_escape_string($cliente);
    $sql .= " AND f.cedula_cliente LIKE '%$cliente%'";
}

if (!empty($producto)) {
    $producto = $conn->real_escape_string($producto);
    $sql .= " AND d.nombre LIKE '%$producto%'";
}

if (!empty($fecha)) {
    $fecha = $conn->real_escape_string($fecha);
    $sql .= " AND f.fecha = '$fecha'";
}

$sql .= " GROUP BY f.id ORDER BY f.fecha DESC";

$result = $conn->query($sql);

$facturas = [];
while ($row = $result->fetch_assoc()) {
    $facturas[] = $row;
}

echo json_encode($facturas);
?>
